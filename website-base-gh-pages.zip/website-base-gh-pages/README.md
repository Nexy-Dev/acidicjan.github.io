# website-base

A simple project to quickstart single-page coding.

## start

`npm install`

edit `package.json`

## development

run server from `dist` folder

use just `grunt` to build page once

alternatively you can use `grunt watch` for watching filechanges and build page when needed

## deployment

deploy just `dist` folder

## license

mit
