var _gaq = [['_setAccount', '<%= pkg.analytics %>'], ['_trackPageview']];
